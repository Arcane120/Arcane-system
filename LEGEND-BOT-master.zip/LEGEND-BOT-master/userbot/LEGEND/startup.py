# HELLO THIS IS 1ST TUTORIAL

# for LEGEND-BOT
from userbot.utils import admin_cmd
import asyncio
@borg.on(admin_cmd(pattern="hi"))
async def legendx(event):
  await event.edit("HELLO MY CODE IS RUNNING")
  await asyncio.sleep(5)
  await event.reply("YEAH WORKING")
  await asyncio.sleep(5)
  await bot.send_message(event.chat_id, "HELLO THIS IS ALSO RUNNING")
  await asyncio.sleep(5)
  await bot.send_message("@LEGENDX22", "HELLO VRO YOUR CODE IS WORKING")
  await asyncio.sleep(5)
  await bot.send_message(1100231654, "ID TRICK ALSO WORKING")
 
# for ultroid
import asyncio
@ultroid_cmd(pattern="hi")
async def legendx(event):
  await event.edit("HELLO MY CODE IS RUNNING")
  await asyncio.sleep(5)
  await event.reply("YEAH WORKING")
  await asyncio.sleep(5)
  await bot.send_message(event.chat_id, "HELLO THIS IS ALSO RUNNING")
  await asyncio.sleep(5)
  await bot.send_message("@LEGENDX22", "HELLO VRO YOUR CODE IS WORKING")
  await asyncio.sleep(5)
  await bot.send_message(1100231654, "ID TRICK ALSO WORKING")
 

# for grand official
import asyncio
from LEGEND import telethn as bot 
from LEGEND.events import register
@register(pattern="/hi")
async def hehe(event):
# bots cannot use event.edit method
  await asyncio.sleep(5)
  await event.reply("YEAH WORKING")
  await asyncio.sleep(5)
  await bot.send_message(event.chat_id, "HELLO THIS IS ALSO RUNNING")
  await asyncio.sleep(5)
  await bot.send_message("@LEGENDX22", "HELLO VRO YOUR CODE IS WORKING")
  await asyncio.sleep(5)
  await bot.send_message(1100231654, "ID TRICK ALSO WORKING")
