import time
import datetime
from . import legend
def upt():
   uptm = await legend.get_readable_time((time.time() - StartTime))
