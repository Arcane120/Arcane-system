'''
Teri ma ko chod raha hu bhosdike zada post daalna aata h channel pe
Bhosdike yahi patak ke chod dunga
Apni baap ki aulad h to pm kr 
Chod Tu gey h teri gaand me dum ni h
Hehehehe 😂
'''
