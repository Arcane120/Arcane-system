#Made By @LEGENDX22

""" Making A Shayri... 
    Command .rshayri
    By @LEGENDX22 """

from telethon import events
import asyncio
import os
import sys
import random
from userbot import ALIVE_NAME, CMD_HELP
from userbot.utils import admin_cmd, edit_or_reply


DEFAULTUSER = str(ALIVE_NAME) if ALIVE_NAME else "Hell User"

legendx22 = bot.uid

@bot.on(admin_cmd(pattern=r"shayri$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit(f"Making A Shayri.......")
    await asyncio.sleep(2)
    h=(random.randrange(1,58))
    if h==1:
        await event.edit(f"🙂Kitna Khusnuma Hoga,\nWoh Meri Maut Ka Manjar\nJab Mujhe Thukrane Wale\nKhud Mujhe Paane Ke Liye,\nAansu Bahayange!!!☺️\n\n\n ✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==2:
        await event.edit(f"Zindagi me baar baar\nKoi sahara nahi milta,\n\nBaar baar koi\nPyaar se pyara nahi milta,\n\nJo paas hai ussy sambhal ke rakhna,\nKyuki koi khoo jaaye toh\n\n**Phir doobara nahi milta...**☺️\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==3:
        await event.edit(f"कभी अपना कहते थे\n आज बेगाना कर गए...\n\nहमसे बात ना करने के लिए\n बहाना कर गए...\n\nशुक्रिया कैसे करूं तुम्हारा \nसमझ नहीं आ रहा...\n\nमेरे इस नियाने से दिल को \n**सयाना कर गए...*\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==4:
        await event.edit(f"Teri Khubsurti Ki Tareef \nMain Ab Kya Likhu\n\n\nKuch Khubsurat Lafzon Ki Talaash \nAb Bhi Hai Mujhe🙂\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==5:
        await event.edit(f"Main Uska Ho Nahi Sakta,\nWoh Meri Ho Nahi Sakti\n\nWoh Aaye Lakh Khwaabon Main,\nSapna Sach Ho Nahi Sakta\n\nMere Nazdeek Ho Kar Bhi,\nNahi Hai Woh Sath Mere\n\nUsse Neend Nahi Aati,\nYaha Main So Nahi Sakta\n\nMohabbat Ka Jo Rishta Hai,\nNaa Jaane Kaisa Rishta Hai\n\nMera Ho Ke Bhi Koi,\n**Mera Ho Nahi Sakta!!!**\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==6:
        await event.edit(f"Dukh yeh nhi,\nKe koi Apna nhi....\n\nDukh Yeh Hai Ke\nKisi ne\n\n\n**APNA BANA KAR CHOR DIA**🙂💔\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==7:
        await event.edit(f"एक बार भूल से ही \nकहा होता \nकी हम किसी और के भी है \nखुदा कसम \nहम तेरे सायें से भी दूर रहते...🙂\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})  ")    
    if h==8:
        await event.edit(f"Dosti Nibhate Nibhate \nUs Se Mohabbat Si Ho Gayi\n\nGam Hi Mile Sahi \nPar Chahat Si Ho Gayi\n\nKarte The Jo Baatain \nRaat Raat Bhar\nAaj Un Se Baat Karne Ki Khwahish Si Ho Gayi\n\nJee Nahi Sakte Ab Us Ke Bin\n**Us Ke Sath Rehne Ki Aadat Si Ho Gayi**\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==9:
        await event.edit(f"Tere Deedar ke lie aate hai\nTeri galiyon me...\n\nWarna awaargi ke lie to\nPura seher pada hai🙂\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==10:
        await event.edit(f"Bass Aakhir baar tere pyaar ko Mehsus karloon\n\nLaut ke fir kabhi tere galiyoon me nhi aaunga\n\nApni barbaad mohabbat ka Zanaja lekar\n**Teri Duniya se bahut dur chala jaunga**\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==11:
        await event.edit(f"Bheed Ki aadat nhi mujhe\nThode me zeena sikh lia humne\n\nDo dost hai,Channd Duae hai\nBass inn khusiyoon ko\nGale laga lia humne🙂\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==12:
        await event.edit(f"दोस्ती जैसे खूबसूरत रिश्ते को \nदफना दिया तुमने \nअब उसे दफन ही रहने दो ।\n\nअब मेरे अंदर कोई जज्बात नहीं बचे \nमर चुका हूं में \nअब तुम मुझे दफन ही रहने दो\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==13:
        await event.edit(f"अगर बुरा न मानो तो कहें???\n\n     हमको भी बुरा लगता है !!!!\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==14:
        await event.edit(f"में क्यों तेरे ख्यालो में खोता रहुँ\n\n     पागल नहीं हूँ में \nजो हर पल तेरे लिए रोता रहुँ !\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==15:
        await event.edit(f"ना **राज** है....जींदगी,...\nना **नाराज**है....जींदगी,...\nबस जो भी है,........\n वो **आज**है....... जींदगी\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==16:
        await event.edit(f"जब तुम नहीं समझे,\nतब मैंने खुद को कितना समझाया\n\nये तुम कभी नहीं समझोगे\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==17:
        await event.edit(f"Kisi Ne Yun Hi Pooch Liya Humse\nKi Dard Ki Keemat Kya Hai,\nHumne Hanste Huye Kaha\nPata Nahin\n\n**Kuch Apne Muft Me De Gaye**\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==18:
        await event.edit(f"Rekhao ka khel he sara\nKya kare taqdeer ka mara\n\nJis qadar uski qadar ki..\n**Uss qadar beqadar huve ham**\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==19:
        await event.edit(f"तेरी हर बात मुझे अपने तरफ खिंचती क्यूँ हैं,\nतू क्या हैं, कौन हैं, मेरे लिए इतना जरूरी क्यूँ हैं\nमेरे साथ साथ तू साये की तरह क्यूँ हैं,\n\nअगर ऐसा ही हैं तो फिर \nतू मुझसे इतना दूर होके भी\n**पास क्यू हैं\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==20:
        await event.edit(f"नज़र को नज़र की खबर ना लगे\nकोई अच्छा भी इस कदर ना लगे \n\nआपको देखा है बस उस नज़र से\nजिस नज़र से आपको नज़र ना लगे\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==21:
        await event.edit(f"Teri muskurahat Meri pahechan he\nTerri Khushi Meri shan he\n\nKuch bhi nhi he meri jindgi me\nItna smaj le bas tu Meri jaan he\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==22:
        await event.edit(f"💞💞💞💞💞💞💞💞💞💞\n\nमेरा इश्क बड़ा नाज़ुक है इसे सहेज के रखना...,\n\n\nइसे उंगलियों से मत पकड़ना...\nहथेलियों पे रखना...,\n\n💞💞💞💞💞💞💞💞💞💞\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==23:
        await event.edit(f"तेरे इश्क की जंग में,\n          हम मुस्कुराके डट गए,\n\nतलवार से तो बच गए,\n          तेरी मुस्कान से कट गए।\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==24:
        await event.edit(f"💖आँखों में देखी जाती हैं..,,\nप्यार की गहराईयाँ.\n\nशब्दों में तो छुप जाती हैं..,,\nबहुत सी तन्हाईयाँ....💖⚡😘\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==25:
        await event.edit(f"Dhadkan Ye Kehti Hai.\nDil Tere Bin Dhadke Na.\nEk Tu Hi Yaar Mera.\nMujhko Kya Duniya Se Lena\n\n\n ✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==26:
        await event.edit(f"Khud Nahi Jante Kitne Pyare Ho Aap.\nJaan Ho Hamari Par Jaan Se Pyari Ho Aap.\nDuriyon Ke Hone Se Koi Fark Nahi Padta.\nKal Bhi Hamare The Aur Aaj Bhi Hamari Ho Aap\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==27:
        await event.edit(f"Samandar Kinare baithe hai.\nKabhi to leher aaegi.\nKismat badle ya na badle.\nGand to dhul jaegi.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==28:
        await event.edit(f"Mere Dil ke Yeh tukde hai.\nNigaaho se choonu yaara.\nMohabatt ki kahaani hai.\nMohabatt se suno yaara.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==29:
        await event.edit(f"Kaunsa Zakhm Tha Jo Taaza Naa Tha.\nItna Gam Milega Andaza Naa Tha.\nAap Ki Jheel Si Aankhon Kaa Kya Kasoor.\nDubne Wale Ko Hi Gehrai Kaa Andaza Naa Tha\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==30:
        await event.edit(f"Bahte Hue Duriya Ko Kya Modega Koi.\nToote Hue Shishe Ko Kya Jodega Koi.\nChalo Fir Se Dil Lagake Dekhte Hai.\nAb Is Toote Hue Dil Ko Kya Todega Koi\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==31:
        await event.edit(f"Dil Ko Jalate Hai Ham Diye Ki Tarah,\nTeri Zindagi Main Roshni Lane Ke Liye,\nLe Lete Hai Har Kaaton Ko Apni Zindagi Mein,\nBas Teri Rahon Main Phool Bhichane Ke Liye\n\n\n✍️[{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==32:
        await event.edit(f"Pyase Ko Ek Katra Pani Kafi Hai.\nIshq Mein Char Pal Ki Zindgani Kafi Hai.\nDoobne Ko Samander Mein Jayein Kahan.\nAapki Aankh Se Tapka Voh Pani Kafi Hai.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==33:
        await event.edit(f"HAMNE TOH BSS DOST KO HI BEWAFA SAMJHA THHA...\nYAHAAN SACCHA PYAAR V SAATH NHI DIYA🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==34:
        await event.edit(f"Love leads to death 🥱🥱\nOr to a living dead 🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==35:
        await event.edit(f"BAATEN TU KABHI YE NA BHULNA.....\nKOI TERE KAARANN HAI..MRR RHA 🥱🥱🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==36:
        await event.edit(f"Ae dost Tere jaise log ko kaat k fekk dange hm\nMeri taraf aae her toofan ko Teri taraff bhej dange hm...\nLekhin tune Jo saath chorrda hamara ......\nKsm SE badnaam krke tujhe nya dost....\n dhoondh lange hum🥱🥱🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==37:
        await event.edit(f"Bde ajeeb Hain ye Zindagi k raaste.........\nAnjaane modd pe log Mill jaate Hain...khhud ko apna BTA k.....chorrrd jaate Hain...\n. KRTE hai. H baat (Zindagi bhar saath rahenge) interest khtm hone prr......zinda LAASH BNA jaate h🥱🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==38:
        await event.edit(f"Dill jaisa thha waisa hi reh jaata......\nJitne dard thhey UTNE kaafi thhey.......\nZindagi aap me aake aur tadpaa diya.........\nMillla kya u badnaam krke ....zinda LAASh...... DIYA🙃🙃\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==39:
        await event.edit(f"DARD SE IS KADAR DOSTI HO GYI.......\nZINDAGI BEDARD SI HO GYI.......\nJALL  GAY WO ASHIYANA.......JO KABHI BNA HI NHI THHA......\nROSHNI TOH CHORRDO..........\nGHAR MEIN JO MOMABATTIE  THHI WO V KHTM HO GYI.........🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==40:
        await event.edit(f"Zindagi barbaad hai...... Zindagi SE pyaar na Karo.......\nHo raat toh Dinn ka intezaar na Karo.......\nWo Pall v aaega....jiss pal ka INTEZAAR na  ho aako.....\nPRRR uspe kabhi aitbaar na Karo........🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==41:
        await event.edit(f"Dard k saath rhte hue v dosti nhi Hui\nZindagi bedard si hote hue v nhi Hui\nAashiyana toh jall gya\nPrr  Roshni nhi Hui ..........❤️\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==42:
        await event.edit(f"ME: DUNIYA ME AISI KYA CHEEZ HAI JO FREE MEI MILTI HAI............\nMAH HEART : DHOKHA \n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==43:
        await event.edit(f"JO INSAAN AAPKO TADAPTA HUA ....ROTA CHORRD DE NA.......... TOH SAMAJH LENA WO KABHI AAPSE \nPYAAR NHI KRR SKTA.....AGAR KOI PYAAR KAREGA NA......\nTOH WO KABHI AAPKO AISEY NHI CHORRDEGA.......🥱🥱\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==44:
        await event.edit(f"TOOTE HAIN.....ES TARAH DILL ......\nAWAAZ TKK NA AAI....\nHUM JAISEY JEE RHE H.....\nKOI JEE K TOH BTAAE....🙃🙃\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==45:
        await event.edit(f"AANKHON ME AANSU LEKE........\nHOTHON SE MUSKURAAE................\nHUM JAISEY JEE RHE HAIN.......\nKLI JEE K TOH BTAAE...🙃🙃\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==46:
        await event.edit(f"TUJHE KAISEY PTA NA CHALAA.................\nK MAIN TENU PYAAR KRR Di AAN...........\nTUJHE KAISEY PTA NA CHALAA......\nK TERA INTEZAAR KRR DI AAN........🙃\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==47:
        await event.edit(f"MTT CHORRDNA KISIKO USKE HAAL PE.......\nHO SKTA H.......\nAAPKE ALAWA  USKE PAAS AUR KOI NA HO.......🙃🙃\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==48:
        await event.edit(f"🙂Kehti Hain Zindagi Pyaar Kar Ke Toh Dekh ,\n Kya Pata Tha Jis Zindagi Ne Pyaar Mein Jeena Sikhaya,\n Aaj Wahi Gir Ke Samhalna Bhi Sikha Gayi☺️\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==49:
        await event.edit(f"आज कुछ इस कदर याद आयी तेरी ..,\nआँसू गिर पड़े जैसे ...,\nनदी को नया मोड़ मिल गया !!\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==50:
        await event.edit(f"कभी अपना कहते थे \n आज बेगाना कर गए...\n\nहमसे बात ना करने के लिए \n बहाना कर गए... \nशुक्रिया कैसे करूं तुम्हारा \nसमझ नहीं आ रहा...\nमेरे इस नियाने से दिल को \n**सयाना कर गए...* \n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==51:
        await event.edit(f"जानती हूँ जवाब देना आसान नही \nपर कोशिश भी नही करते तुम ,\n मेरा हाल जानने की !!\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==52:
        await event.edit(f"हम हर बिछड़न में नई मुलाकात को ढूंढते है !!\nतुम्हारे बार बार छोड़ जाने की अब ,\nआदत सी हो गयी है !!\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==53:
        await event.edit(f"सोचते तो तब भी थे हम \nतुम मेरे नही हो सकते !!\nअब भी यकीन कहाँ है \n के तुम कभी मेरे थे !!\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==54:
        await event.edit(f"पगला है वो ,\nना जाने इतना क्यों प्यार करता है !!\nकुछ बातें मेरी \n  कहने से पहले ही समझ जाता है !! \n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")    
    if h==55:
        await event.edit(f"आज कल हाल कुछ  \n Telephone booth की \nतरह हो गया है !!\n लोग आते है बात करते है ,\nऔर बस चले जाते है !\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==56:
        await event.edit(f"दिल रोकना तो बहोत चाहता है \nमगर रोकेंगे नही ....!\nना तुम हमारे कुछ हो \nऔर हम भी तुम्हारे कुछ नही !!\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==57:
        await event.edit(f"फर्क नही पड़ता सच मे ,\n कोई आये कोई जाए !!\nबस जो दिल को बार बार \n आदतें लग जाती है ना \nकिसी की ..!!\n बस छुड़ाने में कुछ देर लगती है !\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==58:
        await event.edit(f"Not in mood. Sorry!!!!")

@bot.on(admin_cmd(pattern=r"hflirt$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit(f"Hey! Here's a fact about you......")
    await asyncio.sleep(2.3)
    h=(random.randrange(1,8)) 
    if h==1:
        await event.edit(f"Doctor Ne Advice Kia Hai Ki Sone Se Pahle Apki Pic Dekh Kar Sona Jaroori Hai, Warna Heart Attack Aa Sakta Hai.😨\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==2:
        await event.edit(f"☺️Ap Itne Cute Ho Ki Agar Mai Msg Na Bhi Karna Chahu.To Bhi Mera Hath Khud Keypad Pr Chalne Lagta Hai😶.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==3:
        await event.edit(f"😋Aag joh dil mein lagi hai, usse duniya mein laga doonga main ... joh teri doli uthi, zamaane ko jalaa doonga main😏\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==4:
        await event.edit(f"Jaldi se koi bhagwan ko bulao kyuki ek pari kho gayi hain aur wo pari yaha mujhse chatting kar rahi hain😛.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==5:
        await event.edit(f"Meri aankho 👀ko kuch ho gaya hain, aap per se hat hi nahi rahi hain😶\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==6:
        await event.edit(f"🤨Aap choro ke rani lagte ho kyuki aapne mera dil chura liya hain😘\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==7:
        await event.edit(f"👀Aapki aankhe ocean ki tarah blue he aur me usme har baar dub jata hu🙂\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==8:
        await event.edit(f"📷Aap ek camera ki tarah ho jab bhi aapka photos dekhta hu meri automatic smile aaa jati hain🙈\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
        
        
@bot.on(admin_cmd(pattern=r"eflirt$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit(f"Hey! Here's a fact about you......")
    await asyncio.sleep(2.3)
    h=(random.randrange(1,12)) 
    if h==1:
        await event.edit(f"Your lips look lonely would they like to meet mine?\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==2:
        await event.edit(f"There isn’t a word in the dictionary to describe how beautiful you are\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==3:
        await event.edit(f"I have had a really bad day and it always makes me feel better to see a pretty girl smile. So, would you smile for me?\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==4:
        await event.edit(f"I lost my teddy bear can i sleep with you tonight?\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==5:
        await event.edit(f"I’m no organ donor but I’d be happy to give you my heart.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==6:
        await event.edit(f"If I had to rate you out of 10 I’d rate you a 9… because I am the one that you are missing\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==7:
        await event.edit(f"Can I follow you? Cause my mom told me to follow my dreams\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==8:
        await event.edit(f"Your hand looks heavy can i hold it for you?\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==9:
        await event.edit(f"You may fall from the sky, you may fall from a tree, but the best way to fall… is in love with me.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==10:
        await event.edit(f"Are you the sun? Because you’re so beautiful it’s blinding me\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==11:
        await event.edit(f"I should call you Google, because you have everything I’m looking for.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==12:
        await event.edit(f"Can you kiss me on the cheek so I can at least say a cute girl kissed me tonight?\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
        

@bot.on(admin_cmd(pattern=r"attitude$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit(f"🤙")
    await asyncio.sleep(2)
    h=(random.randrange(1,8)) 
    if h==1:
        await event.edit(f"Dil nhi karta ab\n kisi se dil lagane ko \n bohot aati hai tere jaise \n keh deta hu hoon laut jane ko.\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==2:
        await event.edit(f"humari hesiyat ka andaza tum ye\n jaan ke laga lo hum kabhi unke \n nahi hote jo har kisi ke ho jate hai \n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==3:
        await event.edit(f"Attitude तो अपना भी खानदानी है,\nऔर तू मेरे दिल की रानी है, \nइसलिये कह रहा हूँ मान जा, \nक्योंकि अपनी तो करोड़ो दीवानी हैं।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==4:
        await event.edit(f"मेरा वाला थोड़ा लेट आयेगा,\n लेकिन जब आयेगा तो लाखो में एक आयेगा।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==5:
        await event.edit(f"इतना Attitude न दिखा जिंदगी में तकदीर बदलती रहती है,\n शीशा वहीं रहता है,\n पर तस्वीर बदलती रहती है।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==6:
        await event.edit(f"हम से है ज़माना, ज़माने से हम नही,\nकोई हम से नज़रे मिलाये, \nकिसी मे इतना दम नही।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==7:
        await event.edit(f"हम तो शौक तलवारों के पाला करते हैं,\nबन्दूकों की ज़िद तो बच्चे किया करते हैं।\nशेर अपना शिकार करते हैं और हम अपने Attitude से वार करते हैं।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==8:
        await event.edit(f"शेर अपना शिकार करते हैं\n और हम अपने Attitude से वार करते हैं।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
        

@bot.on(admin_cmd(pattern="gbye ?(.*)"))
async def _(event):
    if event.fwd_from:
        return
    await event.edit(f"Hey! Read this and go🙂")
    await asyncio.sleep(2.3)
    h=(random.randrange(1,18))
    if h==1:
        await event.edit(f" जिंदगी में तन्हा रहना तो मुमकिन नहीं,\nतेरे साथ चलना दुनिया को गवारा भी नहीं,\nइसलिए, तेरा-मेरा दूर जाना ही बेहतर है।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==2:
        await event.edit(f"कुछ दिन साथ चलने वाले,\nथोड़ा और साथ चलने की तमन्ना थी,\nमजबूरी है कहना ही पड़ेगा अलविदा।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==3:
        await event.edit(f"न कहा न कुछ सुना, बस चुपके से चल दिए,\nमोहब्बत के उन्होंने सारे मायने बदल दिए,\अब तो तन्हा गलियों में गुजरेगी हर शाम,\nमर भी गए, तो भी नहीं भूलेंगे उनका नाम।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==4:
        await event.edit(f"पास थे, तो रोने की वजह बनते थे,\nदूर जाकर शायद मुस्कुराना सीख लें आप।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==5:
        await event.edit(f"दोबारा मिलें जिंदगी में यह दुआ करेंगे,\nदूर रहकर भी नजदीक होने की चाह करेंगे।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==6:
        await event.edit(f"माफ करना मुझे दूर तो जाना पड़ेगा,\nपास होकर भी तुम्हे अब भूल जाना पड़ेगा।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==7:
        await event.edit(f"वो शाम सुहानी थी जो गुजरी तेरे साथ,\nबिन तेरे अब कैसे कटेगी सारी रात,\nसमझ लो तुम भी यह मजबूरी है दिल की,\nनहीं गए, तो कैसे कल फिर होगी मुलाकात।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==8:
        await eventt.edit(f"तेरे साथ मुस्कुराना और ठोकरों से संभलना सीखा है,\nआता नहीं अलविदा कहना बस रोकर जताना सीखा है।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==9:
        await event.edit(f"यार तेरी दोस्ती को सलाम है,\nअलविदा कहकर भी हंसा दिया,\nयह बस तेरी यारी का कमाल है।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==10:
        await event.edit(f"ताउम्र तेरे साथ बीती रातों को फिर याद करेंगे,\nकह सकें अलविदा तुझसे इसलिए मेरे यार,\nआंसू का एक भी कतरा बहाए बिना बात करेंगे।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==11:
        await event.edit(f"रूठा जमाना जिंदगी भी रूठी,\nतभी तो तेरे-मेरे बीच ये दूरी छूटी,\nसमझ लेना तुम है ये मेरी मजबूरी,\nवरना न आने देता तेरे-मेरे बीच यह दूरी।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==12:
        await event.edit(f"करीब आते-आते तू कुछ दूर सा हो गया है,\nशाम को अलविदा कह तू कहीं गुम सा गया है,\nचाहता हूं मैं करीब होने का एहसास तेरे पर,\nखुशी के खातिर तेरी तुझे अलविदा कह गया हूं।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==13:
        await event.edit(f"खुश हूं फिर भी ये आंखे नम हैं,\nन चाहते हुए भी दूर जाने का गम है।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==14:
        await event.edit(f"दूर जाने की खबर सुनकर ये धड़कने रुक जाती हैं,\nअलविदा कहने के वक्त यार मेरी आंखें भर आती हैं।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")#creadit to legendx22,sawan
    if h==15:
        await event.edit(f" अब हर लम्हा तुम्हारे बिना सूना सा लगेगा,\nअलविदा कहकर तुम्हारी यादों में जीना पड़ेगा।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==16:
        await event.edit(f"अब हलचल है दिल में नई उम्मीद की तलाश के लिए,\nकहना पड़ेगा अलविदा नई मंजिल की तलाश के लिए\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==17:
        await event.edit(f" जब तुम जाते हो, तो गुलिस्तां के सभी फूल झड़ जाते हैं,\nसंभलकर कहो अलविदा जाते-जाते पेड़ों से क्यों टकरा जाते हो।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
    if h==18:
        await event.edit(f" तिरछी निगाहों से जो देखा उन्होंने,\nतो हम मदहोश हो चले,\nजब पता चला कि वो अलविदा कहने आए,\nतो हम बेहोश हो चले।\n\n\n✍️ [{DEFAULTUSER}](tg://user?id={legendx22})")
        
        
