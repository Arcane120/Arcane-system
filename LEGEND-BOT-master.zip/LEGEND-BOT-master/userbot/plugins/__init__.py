from userbot import simpdef
from ..helper import functions as legend


simpmusic = simpdef.simpmusic 
simpmusicvideo = simpdef.simpmusicvideo

