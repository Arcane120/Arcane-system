Nikal madarchod
Ise bhi kang krle lodu krle aagyaa he to 
Krlena madarchod 😂

